<?xml version="1.0" encoding="ASCII" standalone="no"?>
<map version="0.7.1">
    <node ID="4ED39FBD-1BCC-443C-87BE-A5A0730C7FC1" TEXT="LuckCat&#23458;&#25143;&#31471;&#23618;&#27425;" FOLDED="false" COLOR="#000000">
        <font NAME="STHeitiSC-Light" SIZE="13"></font>
        <edge COLOR="#7F7F7F"></edge>
        <node ID="49D6AAB7-63C2-44A8-8434-733F144B0232" TEXT="Class" POSITION="right" FOLDED="false" COLOR="#000000">
            <font NAME="STHeitiSC-Light" SIZE="12"></font>
            <edge COLOR="#CC66FF"></edge>
            <node ID="11351CE2-0E85-42D7-BC71-A1FED4E39A07" TEXT="third_platform" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#CC66FF"></edge>
                <node ID="CFE77372-F11C-46AF-A615-7E5B6A23C8D9" TEXT="Gamecenter" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="26A97689-CD5D-4E35-82E8-80D3C1201AF1" TEXT="91SDK" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="345A2DAA-3653-4A94-B7CB-A0998DFC0209" TEXT="&#26426;&#38155;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
            </node>
            <node ID="3122C9C8-BCC0-4F5C-98EA-0C3B836FC0E1" TEXT="UI" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#CC66FF"></edge>
                <node ID="59955273-090A-4CB5-A37D-EC2450839D45" TEXT="Loading
&#21152;&#36733;&#31561;&#24453;&#27169;&#22359;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="F281C323-865E-4820-A394-5A53FE3987E5" TEXT="Login
&#30331;&#24405;/&#36873;&#26381;&#21153;&#27169;&#22359;" FOLDED="false">
                    <font NAME="LucidaGrande" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="DCD4D298-2FCE-4F34-9FEC-595DE6DC539D" TEXT="Main&#8232;&#28216;&#25103;&#39318;&#39029;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="73E31A5E-C914-4B6F-B9E6-931552D890E7" TEXT="Chapter
&#21103;&#26412;/&#31456;&#33410;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="960A4F2F-0FFC-4198-B238-3B2BBE68F9B2" TEXT="Page
&#20851;&#21345;/&#23567;&#33410;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="CAFD589C-331A-4F51-A923-F3D37A5D2F98" TEXT="Battle
&#25112;&#26007;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="0E4E75B3-F94D-45D1-A684-259BD7B3DFC9" TEXT="Option
&#35774;&#32622;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="8B548BE8-A3C9-4DFE-8609-9F9F3BD3F126" TEXT="Chat
&#32842;&#22825;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="D658863D-0B9B-4F17-AEEC-532DBE5CF8D4" TEXT="Message
&#28040;&#24687;" FOLDED="false">
                    <font NAME="ArialMT" SIZE="13"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="0D4DFC5A-15A0-4B84-A34E-24982E00D750" TEXT="Friend
&#160;&#22909;&#21451;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="86EF88D0-E330-4B14-A272-7948E8959DA0" TEXT="Shop
&#21830;&#22478;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="128F3906-BD51-4349-8CC2-7BFED2CDCD62" TEXT="Package
&#21253;&#35065;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="06DFABAA-DC1E-41AD-82FC-B49E2E09E495" TEXT="Purchase
&#20805;&#20540;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="02F2C311-40DD-494E-BD75-D29455DC9EFB" TEXT="PlayerInfo
&#160;&#29609;&#23478;&#20449;&#24687;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="76855FBC-0A4C-41E6-95F6-AD621987415B" TEXT="Appendix
&#36890;&#29992;UI/&#38468;&#24405;" FOLDED="false">
                    <font NAME="LucidaGrande" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
            </node>
            <node ID="01B91ABB-D3D8-41B0-BD33-D6FA08A22865" TEXT="Basic" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#CC66FF"></edge>
                <node ID="79E67B33-CB1D-4D97-90CD-E994F332D253" TEXT="&#25968;&#25454;&#32467;&#26500;&#23450;&#20041;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="92DA1B0C-2896-4BC2-8F85-A34FD08AEA50" TEXT="&#28216;&#25103;&#36923;&#36753;&#24120;&#29992;&#21151;&#33021;&#31867;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="3FA0882D-77F9-4D6B-8B55-AA7B7F8CEAF5" TEXT="&#25511;&#21046;&#31867;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="DEBC29B4-A789-4E5B-8DBA-D4A16745BC01" TEXT="&#25968;&#25454;&#26684;&#24335;&#35299;&#26512;&#31867;(json/amf3)" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                </node>
                <node ID="5DC36E87-2BAD-4E81-8211-3667207F951E" TEXT="&#25968;&#25454;&#31649;&#29702;&#31867;" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#CC66FF"></edge>
                    <node ID="EC2D9198-E45B-4C2C-8EA4-8C63C78002E5" TEXT="&#20851;&#21345;&#25968;&#25454;&#31649;&#29702;&#31867;" FOLDED="false" COLOR="#000000">
                        <font NAME="STHeitiSC-Light" SIZE="12"></font>
                        <edge COLOR="#CC66FF"></edge>
                    </node>
                    <node ID="E2CD5F90-2B2A-4754-B4C4-A48F830FD96E" TEXT="&#22768;&#38899;&#25968;&#25454;&#31649;&#29702;&#31867;" FOLDED="false" COLOR="#000000">
                        <font NAME="STHeitiSC-Light" SIZE="12"></font>
                        <edge COLOR="#CC66FF"></edge>
                    </node>
                    <node ID="3FF16F6B-DB8F-4C31-B741-D731C713EE68" TEXT="&#36164;&#28304;&#25968;&#25454;&#31649;&#29702;&#31867;" FOLDED="false" COLOR="#000000">
                        <font NAME="STHeitiSC-Light" SIZE="12"></font>
                        <edge COLOR="#CC66FF"></edge>
                    </node>
                </node>
            </node>
            <node ID="E2939493-B329-4B82-AC90-259D44D21C62" TEXT="third_party
&#160;&#31532;&#19977;&#26041;&#24211;" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#CC66FF"></edge>
            </node>
        </node>
        <node ID="A86091DF-2861-4FD9-8D58-44C7B60BE793" TEXT="libs" POSITION="left" FOLDED="false" COLOR="#000000">
            <font NAME="STHeitiSC-Light" SIZE="12"></font>
            <edge COLOR="#E5B24C"></edge>
            <node ID="CB1C87E3-0261-4BB7-94E1-EB30A4D3F870" TEXT="cocos2dx" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#E5B24C"></edge>
            </node>
            <node ID="6A410CA5-D40F-4556-B884-5DA2B9A3F078" TEXT="sqlite" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#E5B24C"></edge>
            </node>
            <node ID="87D7A9C2-F754-4DC8-A80B-7489EF2A1E65" TEXT="json" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#E5B24C"></edge>
            </node>
        </node>
        <node ID="AD4DE301-EE31-4706-A7EC-BB93A95F9D5E" TEXT="proj.ios" POSITION="left" FOLDED="false" COLOR="#000000">
            <font NAME="STHeitiSC-Light" SIZE="12"></font>
            <edge COLOR="#FFCC66"></edge>
        </node>
        <node ID="8C2B6C42-6081-4E60-A700-8B0BAF948E3F" TEXT="proj.android" POSITION="left" FOLDED="false" COLOR="#000000">
            <font NAME="STHeitiSC-Light" SIZE="12"></font>
            <edge COLOR="#66FFCC"></edge>
        </node>
        <node ID="8AB492CA-FF7D-4A4D-810A-1B4BF6E6CD22" TEXT="proj.win32" POSITION="left" FOLDED="false" COLOR="#000000">
            <font NAME="STHeitiSC-Light" SIZE="12"></font>
            <edge COLOR="#CCFF66"></edge>
        </node>
        <node ID="8DDFF066-44DD-48DF-AB8E-EEC6FA19E496" TEXT="proj.xxx" POSITION="left" FOLDED="false" COLOR="#000000">
            <font NAME="STHeitiSC-Light" SIZE="12"></font>
            <edge COLOR="#FFE57F"></edge>
        </node>
        <node ID="19048968-FBF8-4229-8A02-F79023281A9B" TEXT="Resources" POSITION="right" FOLDED="false" COLOR="#000000">
            <font NAME="STHeitiSC-Light" SIZE="12"></font>
            <edge COLOR="#66CCFF"></edge>
            <node ID="E23B8DEA-72F2-46B2-A3BC-C770FDD6DEA9" TEXT="audio" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#66CCFF"></edge>
            </node>
            <node ID="8F0CFAB3-E5A8-4CFE-9C2E-69BD106F6E6C" TEXT="image" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#66CCFF"></edge>
                <node ID="4D7AE80B-1F76-4166-A6CC-9B9D67125BF5" TEXT="common" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#66CCFF"></edge>
                </node>
                <node ID="FEA0E158-F469-46B2-B852-393F74864BCE" TEXT="FirstPage" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#66CCFF"></edge>
                </node>
                <node ID="32CAAE69-9825-4FC5-ABAF-11DD1EB29672" TEXT="Chapter" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#66CCFF"></edge>
                </node>
                <node ID="7485A986-A719-4378-AEB5-B9286CDA2B43" TEXT="Page" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#66CCFF"></edge>
                </node>
                <node ID="32280B96-8D77-4C24-AD66-BC5963046755" TEXT="Battle" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#66CCFF"></edge>
                </node>
                <node ID="B642CC7C-4853-4602-9A53-F3A234674E9C" TEXT="icon" FOLDED="false" COLOR="#000000">
                    <font NAME="STHeitiSC-Light" SIZE="12"></font>
                    <edge COLOR="#66CCFF"></edge>
                    <node ID="7225EBD7-966B-40BC-B1AA-143CD08E9B36" TEXT="icon.png icon.list" FOLDED="false" COLOR="#000000">
                        <font NAME="STHeitiSC-Light" SIZE="12"></font>
                        <edge COLOR="#66CCFF"></edge>
                    </node>
                </node>
            </node>
            <node ID="78640AAB-6E89-4E52-95D5-4255BC36A5F5" TEXT="font" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#66CCFF"></edge>
            </node>
            <node ID="A35DB067-A6E6-49FE-A8E3-0A5B386D7398" TEXT="config" FOLDED="false" COLOR="#000000">
                <font NAME="STHeitiSC-Light" SIZE="12"></font>
                <edge COLOR="#66CCFF"></edge>
            </node>
        </node>
    </node>
</map>